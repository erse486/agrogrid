.pragma library

function cut(api, state, operation) {
    operation.before = api.nearby(operation.original).map(part => part.id)
    state.pendingCut = operation
    api.persist(state)

    try {
        api.edit(() => api.add(operation))
        operation.parts = addedParts(api, operation)
        api.check(operation.parts.length === operation.pieces.length,
                  qsTr("Warstwa nie zapisała wszystkich nowych stref."))
        api.check(api.same(api.read(operation.fieldId), operation.original),
                  qsTr("Geometria wybranego pola uległa zmianie."))
        api.edit(() => api.change(operation.fieldId, operation.retained))
        api.check(api.same(api.read(operation.fieldId), operation.retained),
                  qsTr("Warstwa nie zapisała geometrii pierwotnego pola."))
        finishCut(api, state, operation)
    } catch (error) {
        if (settleCut(api, state))
            return
        throw error
    }
}

function addedParts(api, operation) {
    const existing = new Set(operation.before)
    const parts = api.nearby(operation.original).filter(part => !existing.has(part.id))
    const expected = new Set(operation.pieces)
    const seen = new Set()
    const matches = []
    for (const part of parts) {
        const wkt = expected.has(part.wkt) ? part.wkt :
            operation.pieces.find(piece => api.same(part, piece))
        if (!wkt)
            continue
        api.check(!seen.has(wkt), qsTr("W warstwie są powtórzone strefy. Sprawdź je przed ponowieniem."))
        seen.add(wkt)
        matches.push(part)
    }
    return matches
}

function finishCut(api, state, operation) {
    delete operation.before
    delete operation.pieces
    delete state.pendingCut
    state.operations.push(operation)
    api.persist(state)
}

function settleCut(api, state) {
    const operation = state.pendingCut
    if (!operation)
        return false
    const parts = addedParts(api, operation)
    const original = api.read(operation.fieldId)
    if (api.same(original, operation.retained) && parts.length === operation.pieces.length) {
        operation.parts = parts
        finishCut(api, state, operation)
        return true
    }
    api.check(api.same(original, operation.original),
              qsTr("Stan pola zmienił się podczas podziału. Sprawdź warstwę przed ponowieniem."))
    if (parts.length) {
        api.edit(() => api.remove(parts))
        api.check(!addedParts(api, operation).length,
                  qsTr("Warstwa nie usunęła niedokończonego podziału."))
    }
    delete state.pendingCut
    api.persist(state)
    return false
}

function undo(api, state, operation) {
    const original = api.read(operation.fieldId)
    const recovering = state.pendingUndo === operation.id
    const restored = recovering && api.same(original, operation.original)
    api.check(restored || api.same(original, operation.retained),
              qsTr("Pierwotna strefa zmieniła się od zapisu podziału."))
    const remaining = []
    for (const part of operation.parts) {
        const current = api.read(part.id)
        if (restored && !current)
            continue
        api.check(api.same(current, part.wkt) && current.attributes === part.attributes,
                  qsTr("Strefy zostały zmienione od zapisu podziału."))
        remaining.push(part)
    }
    state.pendingUndo = operation.id
    api.persist(state)
    if (!restored) {
        api.edit(() => api.change(operation.fieldId, operation.original))
        api.check(api.same(api.read(operation.fieldId), operation.original),
                  qsTr("Warstwa nie przywróciła granicy pola."))
    }
    if (remaining.length) {
        api.edit(() => api.remove(remaining))
        api.check(remaining.every(part => !api.read(part.id)),
                  qsTr("Warstwa nie usunęła wszystkich stref."))
    }
    operation.undone = true
    delete state.pendingUndo
    api.persist(state)
}
